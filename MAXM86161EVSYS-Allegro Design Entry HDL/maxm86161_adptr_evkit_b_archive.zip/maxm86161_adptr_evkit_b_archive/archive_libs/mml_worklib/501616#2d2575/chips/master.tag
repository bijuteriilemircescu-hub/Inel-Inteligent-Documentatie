chips.prt
